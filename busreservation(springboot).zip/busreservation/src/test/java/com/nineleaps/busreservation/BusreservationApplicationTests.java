package com.nineleaps.busreservation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BusreservationApplicationTests {

	@Test
	void contextLoads() {
	}

}
