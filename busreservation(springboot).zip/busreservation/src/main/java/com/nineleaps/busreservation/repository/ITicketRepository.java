package com.nineleaps.busreservation.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.nineleaps.busreservation.entity.Seat;
import com.nineleaps.busreservation.entity.Ticket;
@Repository
public interface ITicketRepository extends JpaRepository<Ticket,Long>{
	public List<Ticket> findByTicketId(Long ticket_id);
	
}
