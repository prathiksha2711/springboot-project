package com.nineleaps.busreservation.service;

import java.util.List;
import java.util.Optional;

import com.nineleaps.busreservation.entity.Passenger;

public interface IPassengerService {


	public List<Passenger> getAllPassengers();
	public Optional<Passenger> getPassengerById(Long passenger_id);
	public Passenger updatePassenger(Long passenger_id,Passenger updatePassenger);
	public void deletePassenger(Long passenger_id);
	public Passenger insertPassenger(Passenger newPassenger);
	public List<Passenger> findPassengerName(String passenger_name);
}
