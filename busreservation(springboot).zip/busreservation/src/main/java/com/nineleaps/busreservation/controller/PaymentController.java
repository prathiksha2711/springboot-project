package com.nineleaps.busreservation.controller;

import java.util.List;
import java.util.Optional;



//import javax.swing.text.html.Option;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.nineleaps.busreservation.entity.Payment;
import com.nineleaps.busreservation.service.IPaymentService;

import io.swagger.v3.oas.annotations.parameters.RequestBody;
@RestController
public class PaymentController {


	@Autowired
	private IPaymentService PaymentService;
	
	@GetMapping("/getAllPayment")
	public List<Payment>getAllPayment(){
    return PaymentService.getAllPayment();
	}
	
	@PostMapping("/insertpayment")
	public Payment insertPayment(@RequestBody Payment newPayment) {
 return PaymentService.insertPayment(newPayment);
	}
	
	@PutMapping("/updatePayment/{payment_id}")
	public Payment updatePayment(@PathVariable("paymnt_id")Long payment_id, @RequestBody Payment updatedPayment) {
 return PaymentService.updatePayment(payment_id, updatedPayment);
	}
	
	@DeleteMapping("/deletepayment/{payment_id}")
	public void deletePayment(@PathVariable("payment_id")Long payment_id) {
		PaymentService.deletePayment(payment_id);
	}
	
	@GetMapping("/getPaymentById/{payment_id}")
	public Optional<Payment> getPaymentById(Long payment_id) {
      return PaymentService.getPaymentById(payment_id);
	}
	
//	@RequestMapping(value = "/paymenttable", method = RequestMethod.GET)
//    public Payment getPayment() {
//        return PaymentService.getPayment();
//    }
//
//    @RequestMapping(value = "/admin/pricetable", method = RequestMethod.POST)
//    public Payment setPayment(@RequestBody Payment payment) {
//        return PaymentService.updatePayment(null,payment);
//    }
	
}
