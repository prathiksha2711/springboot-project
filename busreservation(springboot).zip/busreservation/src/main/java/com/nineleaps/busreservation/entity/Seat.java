package com.nineleaps.busreservation.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="seat")
public class Seat {
	
	@Id
	@Column(name = "seat_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long seatId;
	@Column(name = "seat_number")
	private String seatNumber;
	@Column(name = "seat_status")
	private String seatStatus;
	@Column(name = "no_of_seats")
	private float noOfSeats;
	
	public Seat() {
		// TODO Auto-generated constructor stub
	}

	public Long getSeatId() {
		return seatId;
	}

	public void setSeatId(Long seatId) {
		this.seatId = seatId;
	}

	public String getSeatNumber() {
		return seatNumber;
	}

	public void setSeatNumber(String seatNumber) {
		this.seatNumber = seatNumber;
	}

	public String getSeatStatus() {
		return seatStatus;
	}

	public void setSeatStatus(String seatStatus) {
		this.seatStatus = seatStatus;
	}

	public float getNoOfSeats() {
		return noOfSeats;
	}

	public void setNoOfSeats(float noOfSeats) {
		this.noOfSeats = noOfSeats;
	}

	public Seat(Long seatId, String seatNumber, String seatStatus, float noOfSeats) {
		super();
		this.seatId = seatId;
		this.seatNumber = seatNumber;
		this.seatStatus = seatStatus;
		this.noOfSeats = noOfSeats;
	}

	public Seat(String seatNumber, String seatStatus, float noOfSeats) {
		super();
		this.seatNumber = seatNumber;
		this.seatStatus = seatStatus;
		this.noOfSeats = noOfSeats;
	}

	@Override
	public String toString() {
		return "Seat [seatId=" + seatId + ", seatNumber=" + seatNumber + ", seatStatus=" + seatStatus + ", noOfSeats="
				+ noOfSeats + "]";
	}

	
	
}
