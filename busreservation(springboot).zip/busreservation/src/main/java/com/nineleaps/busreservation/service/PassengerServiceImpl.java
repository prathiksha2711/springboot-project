package com.nineleaps.busreservation.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.nineleaps.busreservation.entity.Passenger;
import com.nineleaps.busreservation.repository.IPassengerRepository;

@Service
public class PassengerServiceImpl  implements IPassengerService{
	
	private IPassengerRepository passengerRepository;

	@Override
	public List<Passenger> getAllPassengers() {
		// TODO Auto-generated method stub
		return passengerRepository.findAll();
	}

	@Override
	public Optional<Passenger> getPassengerById(Long passenger_id) {
		// TODO Auto-generated method stub
		return passengerRepository.findById(passenger_id);
	}

	@Override
	public Passenger updatePassenger(Long passenger_id, Passenger updatePassenger) {
		// TODO Auto-generated method stub
		return passengerRepository.save(updatePassenger);
	}

	@Override
	public void deletePassenger(Long passenger_id) {
		// TODO Auto-generated method stub
		passengerRepository.deleteById(passenger_id);
		
	}

	@Override
	public Passenger insertPassenger(Passenger newPassenger) {
		// TODO Auto-generated method stub
		return passengerRepository.save(newPassenger);
	}

	@Override
	public List<Passenger> findPassengerName(String passenger_name) {
		// TODO Auto-generated method stub
		return passengerRepository.findByPassengerName(passenger_name);
	}


}
