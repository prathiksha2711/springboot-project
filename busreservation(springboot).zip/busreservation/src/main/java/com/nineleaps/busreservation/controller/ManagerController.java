package com.nineleaps.busreservation.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.nineleaps.busreservation.entity.Manager;

import com.nineleaps.busreservation.service.IManagerService;

import io.swagger.v3.oas.annotations.parameters.RequestBody;

@RestController

public class ManagerController {
	
	@Autowired
	private IManagerService managerService;
	
	@PostMapping("/insertmanager")
	public Manager insertManager(@RequestBody Manager newManager) {
		return managerService.insertManager(newManager);
	}
	
	@GetMapping("/allmanagers")
	public List<Manager> getAllManagers(){
		return managerService.getAllManagers();
	}


}
