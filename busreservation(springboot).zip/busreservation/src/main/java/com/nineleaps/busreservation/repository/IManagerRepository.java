package com.nineleaps.busreservation.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


import com.nineleaps.busreservation.entity.Manager;

@Repository
public interface IManagerRepository extends JpaRepository<Manager, Long>{
	public List<Manager> findByManagerUsername(String managerUsername);

}
