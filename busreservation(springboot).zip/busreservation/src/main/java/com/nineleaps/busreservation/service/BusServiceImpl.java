package com.nineleaps.busreservation.service;

import java.util.List;
import java.util.Optional;

import javax.persistence.Entity;
import javax.persistence.Table;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.nineleaps.busreservation.entity.Bus;
import com.nineleaps.busreservation.repository.IBusRepository;

@Service
public class BusServiceImpl implements IBusService {
	@Autowired
	private IBusRepository BusRepository;

	
	@Override
	public List<Bus> getAllBuses() {
		// TODO Auto-generated method stub
		return BusRepository.findAll();
	}
	
	@SuppressWarnings("deprecation")
	@Override
	public Optional<Bus> getBusById(Long bus_id) {
		// TODO Auto-generated method stub
		return BusRepository.findById(bus_id);
	}
	
	@Override
	public void deleteBus(Long bus_id) {
		BusRepository.deleteById(bus_id);
		
		
	}
	@Override
	public List<Bus> findBusName(String bus_name) {
		// TODO Auto-generated method stub
		return BusRepository.findByBusName(bus_name);
	}
	@Override
	public Bus updateBus(Long bus_id, Bus updateBus) {
		// TODO Auto-generated method stub
		return BusRepository.save(updateBus);
	}
	@Override
	public Bus insertBus(Bus newBus) {
		// TODO Auto-generated method stub
		return BusRepository.save(newBus);
	}
	
}




