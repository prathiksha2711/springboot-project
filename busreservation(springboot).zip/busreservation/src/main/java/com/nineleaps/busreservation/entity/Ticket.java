package com.nineleaps.busreservation.entity;

import javax.persistence.CascadeType;
//import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
//import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
//import javax.persistence.JoinColumn;
//import javax.persistence.ManyToOne;
//import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.ForeignKey;
@Entity
@Table(name ="ticket")
public class Ticket {
	
	@Id
	@Column(name = "ticket_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long ticketId;

//	@ManyToOne(cascade = CascadeType.ALL)
//	@JoinColumn(name = "bus_id", foreignKey = @ForeignKey(name = "fk_bus_id"))
//	private Bus bus;
//	
//	@ManyToOne(cascade = CascadeType.ALL)
//	@JoinColumn(name = "user_id",nullable = false, foreignKey = @ForeignKey(name = "fk_user_id"))
//	private User user;
	
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "seat_id", nullable = false)
	private Seat seat;
	
//	@Column(name = "no_of_seats")
//	private Seat noOfSeats;
//	
//	@Column(name = "bus_source")
//	private Bus busSource;
//	
//	@Column(name = "bus_destination")
//	private Bus busDestination;
	public Ticket() {
		// TODO Auto-generated constructor stub
	}
	
	@Column(name = "total_cost")
	private float totalCost;

	public Long getTicketId() {
		return ticketId;
	}

	public void setTicketId(Long ticketId) {
		this.ticketId = ticketId;
	}

	public Seat getSeat() {
		return seat;
	}

	public void setSeat(Seat seat) {
		this.seat = seat;
	}

	public float getTotalCost() {
		return totalCost;
	}

	public void setTotalCost(float totalCost) {
		this.totalCost = totalCost;
	}

	public Ticket(Long ticketId, Seat seat, float totalCost) {
		super();
		this.ticketId = ticketId;
		this.seat = seat;
		this.totalCost = totalCost;
	}

	@Override
	public String toString() {
		return "Ticket [ticketId=" + ticketId + ", seat=" + seat + ", totalCost=" + totalCost + "]";
	}
	
	
	
	

}
