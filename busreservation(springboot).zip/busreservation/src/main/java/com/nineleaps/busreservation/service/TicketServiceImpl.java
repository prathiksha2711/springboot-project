package com.nineleaps.busreservation.service;

import java.util.List;
import java.util.Optional;

import org.apache.catalina.User;
//import org.spring.busreservation.dao.TicketRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nineleaps.busreservation.entity.Bus;
import com.nineleaps.busreservation.entity.Seat;
import com.nineleaps.busreservation.entity.Ticket;
//import com.nineleaps.busreservation.repository.ISeatRepository;
//import com.nineleaps.busreservation.entity.User;
import com.nineleaps.busreservation.repository.ITicketRepository;

@Service

public class TicketServiceImpl implements ITicketService{
	
	@Autowired
    private ITicketRepository ticketRepository;
	
	@Autowired
	private IBusService BusService;
	
	@Autowired
	private ISeatService SeatService;
	
	@Autowired
	private IUserService UserService;
	
	
	
	
	
	public String generateTicket(Long busId,Ticket ticketId,Long userId,Long seatId) {
		
		Bus bus = BusService.getBusById(busId).get();
		Long Bid = bus.getBusId();
		float price = bus.getBusPrice();
		String bussourcee = bus.getBusSource();
		String busdestinationn = bus.getBusDestination();
		String busdatee = bus.getBusDate();
		String bustimee = bus.getBusTime();
		User user = (User) UserService.getUserById(userId).get();
		String Uname = user.getUsername();
		Seat seat = SeatService.getSeatById(seatId).get();
		float Noseat = seat.getNoOfSeats();
		String Status =  seat.getSeatStatus();
		float total = price*Noseat;
		Ticket ticket = getTicket(ticketId);
		ticket.setTotalCost(total);
		String ticketGenerated = "Bus Id:" + Bid +"\n"+ "Bus Price: "+price+"/n"+"Bus Source: "+bussourcee+"/n"+
				"Bus Destination:" + busdestinationn +"\n"+"Bus date:" + busdatee +"\n"+"Bus Time:" + bustimee +"\n"+
				"User Name:" + Uname +"\n"+"No of Seats:" + Noseat +"\n"+"Seat status:" + Status +"\n"+"Total Price to pay:" + total +"\n";
		return ticketGenerated;
	}
		
		
		
		
//	
//	public void bookTicket(int noOfTickets) {
//		
//		int TotalNo = 40;
//		
//		int updatedTickets = TotalNo - noOfTickets;
//		
//		Seat s = new  
//		
//		
//		
//	}
//



	@Override
	public List<Ticket> getAllTicketsOfUser(String username) {
		// TODO Auto-generated method stub
		return ticketRepository.findAll();
	}



	@Override
	public void deleteTicket(Long id) {
		// TODO Auto-generated method stub
		ticketRepository.deleteById(id);
		
	}



	@Override
	public List<Ticket> getAllTickets() {
		// TODO Auto-generated method stub
		return ticketRepository.findAll();
	}



	@Override
	public Optional<Ticket> getTicket(Long id) {
		// TODO Auto-generated method stub
		return ticketRepository.findById(id);
	}
	
	@Override
	public Ticket getTicket(Ticket ticketId) {
		// TODO Auto-generated method stub
		return null;
	}
	
}
