package com.nineleaps.busreservation.service;

import java.util.List;
import java.util.Optional;

import com.nineleaps.busreservation.entity.Bus;
import com.nineleaps.busreservation.entity.Seat;
import com.nineleaps.busreservation.entity.Ticket;

public interface ITicketService {
	public String generateTicket(Long busId,Ticket ticketId,Long userId,Long seatId);
	//Ticket bookTicket(Long connectionId, String username);
    //void cancelBookTicket(Long ticketId, String username);
    List<Ticket> getAllTicketsOfUser(String username);
    void deleteTicket(Long id);
    List<Ticket> getAllTickets();
    Ticket getTicket(Ticket ticketId);
	Optional<Ticket> getTicket(Long id);
	

}
