package com.nineleaps.busreservation.service;

import java.util.List;
import java.util.Optional;


import org.springframework.stereotype.Service;

import com.nineleaps.busreservation.entity.Payment;
import com.nineleaps.busreservation.repository.IPaymentRepository;


@Service
public class PaymentServiceImpl implements IPaymentService{
	
	
		private IPaymentRepository paymentRepository;

		@Override
		public List<Payment> getAllPayment() {
			// TODO Auto-generated method stub
			return paymentRepository.findAll();
		}

		@Override
		public Optional<Payment> getPaymentById(Long payment_id) {
			// TODO Auto-generated method stub
			return paymentRepository.findById(payment_id);
		}

		@Override
		public Payment updatePayment(Long payment_id, Payment updatePayment) {
			// TODO Auto-generated method stub
			return paymentRepository.save(updatePayment);
		}

		@Override
		public void deletePayment(Long payment_id) {
			// TODO Auto-generated method stub
			paymentRepository.deleteById(payment_id);
			
		}

		@Override
		public Payment insertPayment(Payment newPayment) {
			// TODO Auto-generated method stub
			return paymentRepository.save(newPayment);
		}	
//		 @Override
//		 public Payment updatePriceTable(Payment payment) {
//		        paymentRepository.deleteAll();
//		        payment.setPaymentId(null);
//		        return paymentRepository.save(payment);
//		    }
//
//		    @Override
//		    public Payment getPayment() {
//		        List<Payment> tables = paymentRepository.findAll();
//		        return tables.size() > 0 ? tables.get(0) : null;
//		    }
}
