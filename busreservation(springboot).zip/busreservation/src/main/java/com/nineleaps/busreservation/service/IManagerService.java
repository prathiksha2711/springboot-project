package com.nineleaps.busreservation.service;

import java.util.List;
import com.nineleaps.busreservation.entity.Manager;

public interface IManagerService {
	public List<Manager> getAllManagers();
	public Manager insertManager(Manager newManager);
}
