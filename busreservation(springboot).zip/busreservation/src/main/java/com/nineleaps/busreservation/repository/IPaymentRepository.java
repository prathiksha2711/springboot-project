package com.nineleaps.busreservation.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

//import com.nineleaps.busreservation.entity.Bus;
import com.nineleaps.busreservation.entity.Payment;

public interface IPaymentRepository extends JpaRepository<Payment,Long>{
	public List<Payment> findByPaymentId(Long paymentId);

}
