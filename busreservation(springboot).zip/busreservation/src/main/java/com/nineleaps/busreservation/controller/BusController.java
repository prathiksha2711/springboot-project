package com.nineleaps.busreservation.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nineleaps.busreservation.entity.Bus;
import com.nineleaps.busreservation.service.IBusService;

import io.swagger.v3.oas.annotations.parameters.RequestBody;

@RestController
public class BusController {
	@Autowired
	private IBusService BusService;
	
	@GetMapping("/getAllBus")
	public List<Bus>getAllBus(){
 return BusService.getAllBuses();
	}
	
	@PostMapping("/insertbus")
	public Bus insertBus(@RequestBody Bus newBus) {
 return BusService.insertBus(newBus);
	}
	
	@PutMapping("/updateBus/{bus_id}")
	public Bus updateBus(@PathVariable("bus_id")Long busId, @RequestBody Bus updatedBus) {
 return BusService.updateBus(busId, updatedBus);
	}
	
	@DeleteMapping("/deletebus/{bus_id}")
	public void deleteBus(@PathVariable("bus_id")Long bus_Id) {
        BusService.deleteBus(bus_Id);
	}
	
	@GetMapping("/getBusById/{bus_id}")
	public Optional<Bus> getBusById(Long bus_id) {
      return BusService.getBusById(bus_id);
	}
	@GetMapping("/getBusByName/{bus_name}")
	public List<Bus> findBusName(@PathVariable ("bus_name") String busName) {
 return BusService.findBusName(busName);
	}

}
