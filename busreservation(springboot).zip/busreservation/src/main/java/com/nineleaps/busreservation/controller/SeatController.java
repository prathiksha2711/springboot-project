package com.nineleaps.busreservation.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nineleaps.busreservation.entity.Seat;
import com.nineleaps.busreservation.service.ISeatService;

import io.swagger.v3.oas.annotations.parameters.RequestBody;

@RestController
public class SeatController {
	@Autowired
	private ISeatService SeatService;
	
	@GetMapping("/getAllSeats")
	public List<Seat>getAllSeats(){
 return SeatService.getAllSeats();
	}
	
	@PostMapping("/insertseat")
	public Seat insertSeat(@RequestBody Seat newSeat) {
 return SeatService.insertSeat(newSeat);
	}
	
	@PutMapping("/updateSeat/{seat_id}")
	public Seat updateSeat(@PathVariable("seat_id")Long seat_id, @RequestBody Seat updatedSeat) {
 return SeatService.updateSeat(seat_id, updatedSeat);
	}
	
	@DeleteMapping("/deleteseat/{seat_id}")
	public void deleteSeat(@PathVariable("seat_id")Long seat_id) {
        SeatService.deleteSeat(seat_id);
	}
	
	@GetMapping("/getSeatById/{seat_id}")
	public Optional<Seat> getSeatById(Long seat_id) {
      return SeatService.getSeatById(seat_id);
	}
	
	

}
