package com.nineleaps.busreservation.controller;

public class PassengerController {

}
