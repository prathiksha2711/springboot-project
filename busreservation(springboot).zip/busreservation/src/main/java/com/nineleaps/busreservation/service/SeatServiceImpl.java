package com.nineleaps.busreservation.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nineleaps.busreservation.entity.Bus;
import com.nineleaps.busreservation.entity.Seat;
import com.nineleaps.busreservation.repository.ISeatRepository;

@Service
public class SeatServiceImpl implements ISeatService{
	
	@Autowired
	private ISeatRepository SeatRepository;


//	public Optional<Seat> getSeatById(Long seatId) {
//		// TODO Auto-generated method stub
//		return SeatRepository.findById(seatId);
//	}

	@Override
	public Seat updateSeat(Long seat_id, Seat updatedSeat) {
		// TODO Auto-generated method stub
		return SeatRepository.save(updatedSeat);
	}

	@Override
	public void deleteSeat(Long seat_id) {
		// TODO Auto-generated method stub
		 SeatRepository.deleteById(seat_id);
	}

	@Override
	public Seat insertSeat(Seat newSeat) {
		// TODO Auto-generated method stub
		return SeatRepository.save(newSeat);
	}

	@Override
	public List<Seat> getAllSeats() {
		// TODO Auto-generated method stub
		return SeatRepository.findAll();
	}

	@Override
	public Optional<Seat> getSeatById(Long seatId) {
		// TODO Auto-generated method stub
		return SeatRepository.findById(seatId);
	}

	
	
}
