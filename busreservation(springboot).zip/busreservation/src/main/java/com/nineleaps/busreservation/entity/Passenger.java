package com.nineleaps.busreservation.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="passenger")
public class Passenger {
	
	@Id
	@Column(name = "passenger_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long passengerId;
	@Column(name = "passenger_name")
	 private String passengerName;
	@Column(name = "passenger_number")
	 private String passengerNumber;
	@Column(name = "passenger_email")
	 private String passengerEmail;
	@Column(name = "passenger_address")
	 private String passengerAddress;
	@Column(name = "passenger_gnder")
	 private String passengerGender;
	public Passenger() {
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Passenger [passengerId=" + passengerId + ", passengerName=" + passengerName + ", passengerNumber="
				+ passengerNumber + ", passengerEmail=" + passengerEmail + ", passengerAddress=" + passengerAddress
				+ ", passengerGender=" + passengerGender + "]";
	}
	public Passenger(String passengerName, String passengerNumber, String passengerEmail, String passengerAddress,
			String passengerGender) {
		super();
		this.passengerName = passengerName;
		this.passengerNumber = passengerNumber;
		this.passengerEmail = passengerEmail;
		this.passengerAddress = passengerAddress;
		this.passengerGender = passengerGender;
	}
	public Long getPassengerId() {
		return passengerId;
	}
	public void setPassengerId(Long passengerId) {
		this.passengerId = passengerId;
	}
	public String getPassengerName() {
		return passengerName;
	}
	public void setPassengerName(String passengerName) {
		this.passengerName = passengerName;
	}
	public String getPassengerNumber() {
		return passengerNumber;
	}
	public void setPassengerNumber(String passengerNumber) {
		this.passengerNumber = passengerNumber;
	}
	public String getPassengerEmail() {
		return passengerEmail;
	}
	public void setPassengerEmail(String passengerEmail) {
		this.passengerEmail = passengerEmail;
	}
	public String getPassengerAddress() {
		return passengerAddress;
	}
	public void setPassengerAddress(String passengerAddress) {
		this.passengerAddress = passengerAddress;
	}
	public String getPassengerGender() {
		return passengerGender;
	}
	public void setPassengerGender(String passengerGender) {
		this.passengerGender = passengerGender;
	}
	public Passenger(Long passengerId, String passengerName, String passengerNumber, String passengerEmail,
			String passengerAddress, String passengerGender) {
		super();
		this.passengerId = passengerId;
		this.passengerName = passengerName;
		this.passengerNumber = passengerNumber;
		this.passengerEmail = passengerEmail;
		this.passengerAddress = passengerAddress;
		this.passengerGender = passengerGender;
	}

}
