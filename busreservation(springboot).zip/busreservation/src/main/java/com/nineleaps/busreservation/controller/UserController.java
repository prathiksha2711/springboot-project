package com.nineleaps.busreservation.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nineleaps.busreservation.entity.User;
import com.nineleaps.busreservation.service.IUserService;

import io.swagger.v3.oas.annotations.parameters.RequestBody;
@RestController
public class UserController {
	@Autowired
	private IUserService UserService;
	@GetMapping("/getAllUsers")
	public List<User>getAllUsers(){
 return UserService.getAllUsers();
	}
	
	@PostMapping("/insertuser")
	public User insertUser(@RequestBody User newUser) {
 return UserService.insertUser(newUser);
	}
	
	@PutMapping("/updateUser/{user_id}")
	public User updateUser(@PathVariable("user_id")Long user_id, @RequestBody User updatedUser) {
 return UserService.updateUser(user_id, updatedUser);
	}
	
	@DeleteMapping("/deleteuser/{user_id}")
	public void deleteUser(@PathVariable("user_id")Long user_id) {
		UserService.deleteUser(user_id);
	}
	
	@GetMapping("/getUserById/{User_id}")
	public Optional<User> getUserById(Long user_id) {
      return UserService.getUserById(user_id);
	}
	

}
