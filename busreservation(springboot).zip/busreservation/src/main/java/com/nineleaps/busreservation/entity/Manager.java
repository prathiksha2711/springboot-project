package com.nineleaps.busreservation.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;


@Entity
@Table(name = "manager")
public class Manager {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="manager_id", nullable = false)
    private Long managerId;
	
	@NotEmpty
	@Size(min=2,message="Name should have atleast 2 characters")
	@Column(name = "manager_username")
	private String managerUsername;
	
	@Column(name = "manager_password",nullable = false)
	private String managerPassword;
	
	public Manager() {
		// TODO Auto-generated constructor stub
	}

	public Manager(Long managerId,
			@NotEmpty @Size(min = 2, message = "Name should have atleast 2 characters") String managerUsername,
			String managerPassword) {
		super();
		this.managerId = managerId;
		this.managerUsername = managerUsername;
		this.managerPassword = managerPassword;
	}

	public Manager(@NotEmpty @Size(min = 2, message = "Name should have atleast 2 characters") String managerUsername,
			String managerPassword) {
		super();
		this.managerUsername = managerUsername;
		this.managerPassword = managerPassword;
	}

	public Long getManagerId() {
		return managerId;
	}

	public void setManagerId(Long managerId) {
		this.managerId = managerId;
	}

	public String getManagerUsername() {
		return managerUsername;
	}

	public void setManagerUsername(String managerUsername) {
		this.managerUsername = managerUsername;
	}

	public String getManagerPassword() {
		return managerPassword;
	}

	public void setManagerPassword(String managerPassword) {
		this.managerPassword = managerPassword;
	}

	@Override
	public String toString() {
		return "Manager [managerId=" + managerId + ", managerUsername=" + managerUsername + ", managerPassword="
				+ managerPassword + "]";
	}
	
	
	
}
