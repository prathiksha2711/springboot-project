package com.nineleaps.busreservation.controller;

//import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nineleaps.busreservation.entity.Bus;
import com.nineleaps.busreservation.entity.Seat;
import com.nineleaps.busreservation.entity.Ticket;
//import com.nineleaps.busreservation.service.IBusService;
import com.nineleaps.busreservation.service.ITicketService;

@RestController
public class TicketController {

@Autowired
private ITicketService ticketService;
	
@GetMapping("/getticket/{ticket_id}")
public String generateTicket(Long busId,Ticket ticketId,Long userId,Long seatId) {
 return ticketService.generateTicket(busId, ticketId, userId, seatId);
}
}
