package com.nineleaps.busreservation.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.nineleaps.busreservation.entity.Manager;

import com.nineleaps.busreservation.repository.IManagerRepository;

@Service
public class ManagerServiceImpl implements IManagerService{
	
	@Autowired
	private IManagerRepository managerRepo;

	@Override
	public List<Manager> getAllManagers() {
		// TODO Auto-generated method stub
		return managerRepo.findAll();
	}

	@Override
	public Manager insertManager(Manager newManager) {
		// TODO Auto-generated method stub
		return managerRepo.save(newManager);
	}

}
