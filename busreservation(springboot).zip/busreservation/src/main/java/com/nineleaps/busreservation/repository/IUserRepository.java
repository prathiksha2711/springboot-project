package com.nineleaps.busreservation.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nineleaps.busreservation.entity.User;

public interface IUserRepository extends JpaRepository<User,Long>{
	public List<User> findByUserNumber(String user_number);
}


