package com.nineleaps.busreservation.service;

import java.util.List;
import java.util.Optional;

import com.nineleaps.busreservation.entity.Payment;

public interface IPaymentService {


	public List<Payment> getAllPayment();
	public Optional<Payment> getPaymentById(Long payment_id);
	public Payment updatePayment(Long payment_id,Payment updatedPayment);
	public void deletePayment(Long payment_id);
	public Payment insertPayment(Payment newPayment);
//	public Payment updatePriceTable(Payment payment);
//	public Payment getPayment();
}
