package com.nineleaps.busreservation.service;

import java.util.List;
import java.util.Optional;

import com.nineleaps.busreservation.entity.Seat;

public interface ISeatService {
	public List<Seat> getAllSeats();
	public Optional<Seat> getSeatById(Long seatId);
	public Seat updateSeat(Long seat_id,Seat updatedSeat);
	public void deleteSeat(Long seat_id);
	public Seat insertSeat(Seat newSeat);

}
