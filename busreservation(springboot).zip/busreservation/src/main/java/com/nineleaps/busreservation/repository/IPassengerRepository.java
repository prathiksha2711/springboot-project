package com.nineleaps.busreservation.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.nineleaps.busreservation.entity.Passenger;

@Repository
public interface IPassengerRepository extends JpaRepository<Passenger,Long>{
		public List<Passenger> findByPassengerName(String passenger_name);
	}

