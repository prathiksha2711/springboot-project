package com.nineleaps.busreservation.service;

import java.util.List;
import java.util.Optional;

import com.nineleaps.busreservation.entity.Bus;

public interface IBusService {
	public List<Bus> getAllBuses();
	public Optional<Bus> getBusById(Long busId);
	public Bus updateBus(Long bus_id,Bus updateBus);
	public void deleteBus(Long bus_id);
	public Bus insertBus(Bus newBus);
	public List<Bus> findBusName(String bus_name);
}


