package com.nineleaps.busreservation.entity;

//import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "payment")
public class Payment {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "payment_id")
	private Long paymentId;
	
	
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "ticket_id")
	private Ticket ticket;

	
	@Column(name = "payment_status")
	private String paymentStatus;
	
	
	public Payment() {
		// TODO Auto-generated constructor stub
	}
	public Long getPaymentId() {
		return paymentId;
	}
	public void setPaymentId(Long paymentId) {
		this.paymentId = paymentId;
	}
	public Ticket getTicket() {
		return ticket;
	}
	public void setTicket(Ticket ticket) {
		this.ticket = ticket;
	}
	public String getPaymentStatus() {
		return paymentStatus;
	}
	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}
	public Payment(Long paymentId, Ticket ticket, String paymentStatus) {
		super();
		this.paymentId = paymentId;
		this.ticket = ticket;
		this.paymentStatus = paymentStatus;
	}
	public Payment(Ticket ticket, String paymentStatus) {
		super();
		this.ticket = ticket;
		this.paymentStatus = paymentStatus;
	}
	@Override
	public String toString() {
		return "Payment [paymentId=" + paymentId + ", ticket=" + ticket + ", paymentStatus=" + paymentStatus + "]";
	}
	
	

	
}
