package com.nineleaps.busreservation.service;

import java.util.List;
import java.util.Optional;

import com.nineleaps.busreservation.entity.User;

public interface IUserService {
	public List<User> getAllUsers();
	public Optional<User> getUserById(Long user_id);
	public User updateUser(Long user_id,User updateduser);
	public void deleteUser(Long user_id);
	public User insertUser(User newUser);
	

}
