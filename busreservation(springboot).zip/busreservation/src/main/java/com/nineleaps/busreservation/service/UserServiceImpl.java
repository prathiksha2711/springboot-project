package com.nineleaps.busreservation.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nineleaps.busreservation.entity.User;
import com.nineleaps.busreservation.repository.IUserRepository;

@Service
public class UserServiceImpl implements IUserService{

	@Autowired
	private IUserRepository userRepository;
	@Override
	public List<User> getAllUsers() {
		// TODO Auto-generated method stub
		return userRepository.findAll();
	}

	@Override
	public Optional<User> getUserById(Long user_id) {
		// TODO Auto-generated method stub
		return userRepository.findById(user_id);
	}

	@Override
	public User updateUser(Long user_id, User updateduser) {
		// TODO Auto-generated method stub
		return userRepository.save(updateduser);
	}

	@Override
	public void deleteUser(Long user_id) {
		// TODO Auto-generated method stub
		userRepository.deleteById(user_id);
	}

	@Override
	public User insertUser(User newUser) {
		// TODO Auto-generated method stub
		return userRepository.save(newUser);
	}
	 

}
