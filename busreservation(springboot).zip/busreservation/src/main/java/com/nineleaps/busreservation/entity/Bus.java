package com.nineleaps.busreservation.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="bus")
public class Bus {

	@Id
	@Column(name = "bus_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long busId;
	@Column(name = "bus_name")
	 private String busName;
	@Column(name = "bus_number")
	 private String busNumber;
	@Column(name = "bus_type")
	 private String busType;
	@Column(name = "bus_source")
	private String busSource;
	@Column(name = "bus_destination")
	private String busDestination;
	@Column(name = "bus_date")
	private String busDate;
	@Column(name = "bus_time")
	private String busTime;
	@Column (name = "bus_price")
	private float busPrice;
	
	
	
	public Bus(Long busId, String busName, String busNumber, String busType, String busSource, String busDestination,
			String busDate, String busTime, float busPrice) {
		super();
		this.busId = busId;
		this.busName = busName;
		this.busNumber = busNumber;
		this.busType = busType;
		this.busSource = busSource;
		this.busDestination = busDestination;
		this.busDate = busDate;
		this.busTime = busTime;
		this.busPrice = busPrice;
	}

	public Bus() {
		// TODO Auto-generated constructor stub
	}

	

	public Bus(String busName, String busNumber, String busType, String busSource, String busDestination,
			String busDate, String busTime, float busPrice) {
		super();
		this.busName = busName;
		this.busNumber = busNumber;
		this.busType = busType;
		this.busSource = busSource;
		this.busDestination = busDestination;
		this.busDate = busDate;
		this.busTime = busTime;
		this.busPrice = busPrice;
	}

	public Bus(String busName, String busNumber, String busType, String busSource, String busDestination,
			String busDate, String busTime) {
		super();
		this.busName = busName;
		this.busNumber = busNumber;
		this.busType = busType;
		this.busSource = busSource;
		this.busDestination = busDestination;
		this.busDate = busDate;
		this.busTime = busTime;
	}

	public Long getBusId() {
		return busId;
	}

	public void setBusId(Long busId) {
		this.busId = busId;
	}

	public String getBusName() {
		return busName;
	}

	public void setBusName(String busName) {
		this.busName = busName;
	}

	public String getBusNumber() {
		return busNumber;
	}

	public void setBusNumber(String busNumber) {
		this.busNumber = busNumber;
	}

	public String getBusType() {
		return busType;
	}
	

	public float getBusPrice() {
		return busPrice;
	}

	public void setBusPrice(float busPrice) {
		this.busPrice = busPrice;
	}

	public void setBusType(String busType) {
		this.busType = busType;
	}

	public String getBusSource() {
		return busSource;
	}

	public void setBusSource(String busSource) {
		this.busSource = busSource;
	}

	public String getBusDestination() {
		return busDestination;
	}

	public void setBusDestination(String busDestination) {
		this.busDestination = busDestination;
	}

	public String getBusDate() {
		return busDate;
	}

	public void setBusDate(String busDate) {
		this.busDate = busDate;
	}

	public String getBusTime() {
		return busTime;
	}

	public void setBusTime(String busTime) {
		this.busTime = busTime;
	}

	@Override
	public String toString() {
		return "Bus [busId=" + busId + ", busName=" + busName + ", busNumber=" + busNumber + ", busType=" + busType
				+ ", busSource=" + busSource + ", busDestination=" + busDestination + ", busDate=" + busDate
				+ ", busTime=" + busTime + "]";
	}
	
	
	

}
